CREATE TABLE IF NOT EXISTS `allergens` (`uuid` VARCHAR(255) , `patientId` VARCHAR(255), `interoperableID` VARCHAR(255), `interoperableDesc` VARCHAR(255), `rxCui` VARCHAR(255), `createdAt` DATETIME, `updatedAt` DATETIME, PRIMARY KEY (`uuid`)) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `clinical_forms` (`uuid` VARCHAR(255) , `patientId` VARCHAR(255), `formTemplateConfigUuid` VARCHAR(255), `businessEntityId` VARCHAR(255), `type` VARCHAR(255), `createdAt` DATETIME, `updatedAt` DATETIME, `appointmentId` VARCHAR(255), PRIMARY KEY (`uuid`)) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `encounters` (`id` VARCHAR(255) , `baseDate` DATETIME, `code` VARCHAR(255), `description` VARCHAR(255), `encounterTime` DATETIME, `patientId` VARCHAR(255), `providerId` VARCHAR(255), `createdAt` DATETIME NOT NULL, `updatedAt` DATETIME NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `form_templates` (`uuid` VARCHAR(255) NOT NULL , `name` VARCHAR(255), `code` VARCHAR(255) NOT NULL UNIQUE, `type` VARCHAR(255), `source` VARCHAR(255), `createdAt` DATETIME, `updatedAt` DATETIME, UNIQUE `form_templates_code_unique` (`code`), PRIMARY KEY (`uuid`)) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `form_template_configs` (`uuid` VARCHAR(255) NOT NULL , `formTemplateUuid` VARCHAR(255), `businessEntityId` VARCHAR(255), `createdAt` DATETIME, `updatedAt` DATETIME, PRIMARY KEY (`uuid`), FOREIGN KEY (`formTemplateUuid`) REFERENCES `form_templates` (`uuid`) ON DELETE NO ACTION ON UPDATE CASCADE) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `medications` (`uuid` VARCHAR(255) , `patientId` VARCHAR(255), `displayName` VARCHAR(255), `dispensableDrugId` VARCHAR(255), `type` VARCHAR(255), `createdAt` DATETIME, `updatedAt` DATETIME, PRIMARY KEY (`uuid`)) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `patients` (`id` VARCHAR(255) , `lastName` VARCHAR(255), `firstName` VARCHAR(255), `birthDate` VARCHAR(255), `sex` VARCHAR(255), `race` VARCHAR(255), `religion` VARCHAR(255), `ethnicity` VARCHAR(255), `maritalStatus` VARCHAR(255), `createdAt` DATETIME NOT NULL, `updatedAt` DATETIME NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB;