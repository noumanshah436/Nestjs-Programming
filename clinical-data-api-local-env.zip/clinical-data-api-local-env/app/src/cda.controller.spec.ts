import { Test, TestingModule } from '@nestjs/testing';
import { CdaController } from './cda.controller';
import { CdaService } from './cda.service';

describe('CdaController', () => {
  let cdaController: CdaController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [CdaController],
      providers: [CdaService],
    }).compile();

    cdaController = app.get<CdaController>(CdaController);
  });

  describe('root', () => {
    it('should return "OK"', () => {
      expect(cdaController.getHealth()).toBe('OK');
    });
  });
});
