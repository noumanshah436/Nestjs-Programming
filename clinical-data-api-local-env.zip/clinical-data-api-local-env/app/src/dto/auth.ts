export class GenerateTokenDTO {
  type: string;
  url: string;
  method: string;
  content: {};
  time: string;
}

export class TestTokenDTO {
  type: string;
  url: string;
  method: string;
  content: {};
  token: string;
  time: string;
}
