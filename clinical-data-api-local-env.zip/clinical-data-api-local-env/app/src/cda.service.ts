import { Injectable } from '@nestjs/common';
import { InjectS3, S3 } from 'nestjs-s3';
import { CareCloudInternalAuth } from '@carecloud/cc-auth-node';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class CdaService {

  carecloudInternalAuth: any;

  constructor(
    @InjectS3() private readonly s3: S3,
    private configService: ConfigService,
  ) {
    this.carecloudInternalAuth = new CareCloudInternalAuth({
      internalApiKey: this.configService.get('auth').apiKey,
      internalSignatureSecret: this.configService.get('auth').secret,
      authServiceUrl: this.configService.get('auth').authServiceUrl
    });
  }

  getHealth(): string {
    return 'OK';
  }

  async getTest() {

    console.log('AWS_ACCESS_KEY_ID',process.env.AWS_ACCESS_KEY_ID);
    console.log('AWS_SECRET_ACCESS_KEY',process.env.AWS_SECRET_ACCESS_KEY);
    console.log('AWS_SESSION_TOKEN',process.env.AWS_SESSION_TOKEN);

    try {
      const input = {
        "Bucket": "development.quippe-patient-data-provider",
        "Key": "encounter-notes/5879412"
      };

      const file = await this.s3.getObject(input);

      console.log("RETURN: ", file);

      const data = file.Body.toString();

      return data;

    } catch (e) {
      console.log(e);
    }
  }

  async generateToken(tokenData) {
    console.log("tokenData")
    console.log(tokenData)
    const tokenSpecs = this.carecloudInternalAuth.generateToken(tokenData.type, tokenData.content, tokenData.url, tokenData.time);
    console.log(tokenSpecs);
    return tokenSpecs;
  }

  async testTokenValidation(options) {
    return await this.carecloudInternalAuth.validateTokenByAuthService(options);
  }

  async md5Test(options) {
    const newToken = await this.carecloudInternalAuth.md5Test(options);
  }
}
