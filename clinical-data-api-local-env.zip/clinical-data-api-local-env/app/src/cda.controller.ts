import { Body, Controller, Get, Post, Req } from '@nestjs/common';
import { ApiOperation } from "@nestjs/swagger";
import { CdaService } from './cda.service';
import { GenerateTokenDTO, TestTokenDTO } from './dto/auth';
import { Request } from 'express';

@Controller()
export class CdaController {
  constructor(private readonly cdaService: CdaService) {}


  @ApiOperation({ summary: "check the health status of the app" })
  @Get()
  getHealth(): string {
    return this.cdaService.getHealth();
  }

  @ApiOperation({ summary: "test s3" })
  @Get('test')
  async getTest() {
    return await this.cdaService.getTest();
  }

  @ApiOperation({ summary: "generate token" })
  @Post('generate-token')
  async generateToken(@Body() body: GenerateTokenDTO) {
    if(!body.time) {
      body = Object.assign({}, body, {time: new Date().toUTCString()});
    }
    if(!body.content) {
      body = Object.assign({}, body, {content: ''});
    }
    return await this.cdaService.generateToken(body);
  }

  @ApiOperation({ summary: "generate token" })
  @Post('test-token-validation')
  async testTokenValidation(@Body() body: TestTokenDTO) {

    const options: any = {
      reqMethod: body.method,
      reqContentType: body.type,
      reqPath: body.url,
      timestamp: body.time,
      Authorization: body.token,
      reqPayload: body.content
  }

    return await this.cdaService.testTokenValidation(options);
  }

  @ApiOperation({ summary: "md5 test" })
  @Post('md5-test')
  async md5Test(@Body() body: any) {

    console.log("BODY: ",body);

    return await this.cdaService.md5Test(body);
  }
}
