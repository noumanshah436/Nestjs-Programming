import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
import { CdaModule } from './cda.module';
import * as express from 'express';

async function bootstrap() {
  const app = await NestFactory.create(CdaModule);

  const config = new DocumentBuilder()
    .setTitle("Clinical Data API - OpenAPI Documentation")
    .setDescription("Available Endpoints")
    .setVersion("1.0")
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("api", app, document);

  // Increase request size limit (50MB)
  app.use(express.json({ limit: '50mb' }));
  
  await app.listen(3000);
}
bootstrap();
