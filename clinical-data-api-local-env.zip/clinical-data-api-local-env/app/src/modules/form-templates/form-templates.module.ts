import { Module } from '@nestjs/common';
import { FormTemplatesController } from './form-templates.controller';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from '../auth/auth.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FormTemplate } from '../common/entities/form-template.entity';
import { CommonModule } from '../common/common.module';
import { FormTemplatesService } from './form-templates.service';

@Module({
    imports: [ 
        ConfigModule,
        AuthModule,
        CommonModule,
        TypeOrmModule.forFeature([FormTemplate])
      ],
    controllers: [FormTemplatesController],
    providers: [FormTemplatesService],
})
export class FormTemplatesModule {}
