import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard'; 
import { FormTemplatesService } from './form-templates.service';
import { ApiOperation, ApiParam } from '@nestjs/swagger';

@UseGuards(AuthGuard)
@Controller('form-templates')
export class FormTemplatesController {
    constructor(
        private readonly formTemplatesService: FormTemplatesService,
      ) {}
    
    @Get(':source/:code')
    @ApiParam({ name: 'source', description: "templates's source" })
    @ApiParam({ name: 'code', description: "templates's code" })
    @ApiOperation({ summary: "get one form template by source and code" })
    async getFormTemplateBySourceAndCode(
        @Param('source') source: any,
        @Param('code') code: any,
    ) {
    return await this.formTemplatesService.getFormTemplateBySourceAndCode(source,code);
  }

}
