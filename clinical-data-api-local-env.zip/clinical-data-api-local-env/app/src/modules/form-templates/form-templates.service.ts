import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FormTemplate } from '../common/entities/form-template.entity';
import { S3Service } from '../common/s3.service';

@Injectable()
export class FormTemplatesService {

    constructor(
        @InjectRepository(FormTemplate)
        private formTemplatesRepository: Repository<FormTemplate>,
        private s3_storage: S3Service
    ) { }


    getFormTemplateBySourceAndCode = async ( source: string, code: string ) => {
        return this.formTemplatesRepository
            .createQueryBuilder('formTemplate')
            .where('formTemplate.code= :codeId', { code })
            .getOne();
    }

}
