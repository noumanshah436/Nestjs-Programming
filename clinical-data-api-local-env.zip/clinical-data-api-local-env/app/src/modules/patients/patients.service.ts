import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Patient } from '../common/entities/patient.entity';
import { Encounter } from '../common/entities/encounter-notes.entity';
import { S3Service } from '../common/s3.service';

@Injectable()
export class PatientsService {
  constructor(
    @InjectRepository(Encounter) private encounterRepository: Repository<Encounter>,
    @InjectRepository(Patient) private patientRepository: Repository<Patient>,
    private readonly s3_storage: S3Service,
  ) {}

  getPatientByUUID = async (uuid) => {
    try {
      let key = `patients/${uuid}`;

      return await this.s3_storage.getData(key);
    } catch (error) {
      return {
        error: 'Failed to retrieve patient by uuid',
        message: error.message,
      };
    }
  };

  getPatientEncounterNotes = async (patientId): Promise<any> => {
    return await this.encounterRepository
      .createQueryBuilder('encounters')
      .where('encounters.patientId= :patientId', { patientId })
      .orderBy('encounters.baseDate', 'DESC')
      .getMany();
  };
}
