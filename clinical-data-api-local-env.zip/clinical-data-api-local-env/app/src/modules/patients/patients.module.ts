import { Module } from '@nestjs/common';
import { ConfigModule} from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatientsController } from './patients.controller';
import { PatientsService } from './patients.service';
import { ClinicalFormsService } from './clinical-forms.service';
import { ClinicalForm } from '../common/entities/clinical-form.entity';
import { Patient } from '../common/entities/patient.entity';
import { Encounter } from '../common/entities/encounter-notes.entity';
import { AuthModule } from '../auth/auth.module';
import { CommonModule } from '../common/common.module';
import { S3Module } from 'nestjs-s3';
import { ChangesService } from '../entries/changes.service';
import { EntriesService } from '../entries/entries.service';
import { ImportedEntriesService } from '../entries/imported_entries.service';


@Module({
  imports: [ 
    ConfigModule,
    AuthModule,
    CommonModule,
    S3Module,
    TypeOrmModule.forFeature([ClinicalForm, Patient, Encounter]),
  ],
  controllers: [PatientsController],
  providers: [PatientsService, ClinicalFormsService, ChangesService, EntriesService, ImportedEntriesService],
})
export class PatientsModule {}
