import { IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateClinicalFormDto {
  @IsUUID()
  @IsOptional()
  uuid: string;

  @IsString()
  @IsNotEmpty()
  patientId: string;

  @IsString()
  @IsNotEmpty()
  formTemplateConfigUuid: string;

  @IsString()
  @IsNotEmpty()
  businessEntityId: string;

  @IsString()
  @IsNotEmpty()
  type: string;

  @IsString()
  @IsNotEmpty()
  appointmentId: string;

  @IsString()
  @IsNotEmpty()
  xml: string;

  @IsString()
  @IsNotEmpty()
  findings: string;
}
