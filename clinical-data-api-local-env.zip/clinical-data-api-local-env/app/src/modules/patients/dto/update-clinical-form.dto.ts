import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateClinicalFormDto {
  @IsString()
  @IsOptional()
  patientId: string;

  @IsString()
  @IsOptional()
  formTemplateConfigUuid: string;

  @IsString()
  @IsOptional()
  businessEntityId: string;

  @IsString()
  @IsOptional()
  type: string;

  @IsString()
  @IsOptional()
  appointmentId: string;

  @IsString()
  @IsNotEmpty()
  xml: string;

  @IsString()
  @IsNotEmpty()
  findings: string;
}
