import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ClinicalForm } from '../common/entities/clinical-form.entity';
import { S3Service } from '../common/s3.service';
import { FormBuilder } from '../utils/form_builder';
import { generateUuidV4 } from '../utils/helper_functions';
import {
  CreateClinicalformType,
  UpdateClinicalformType,
  XmlDocType,
} from '../utils/types';

const wrapArray = (obj) => {
  return Array.isArray(obj) ? obj : obj === undefined ? obj : Array.of(obj);
};

@Injectable()
export class ClinicalFormsService {
  constructor(
    @InjectRepository(ClinicalForm)
    private readonly clinicalFormRepository: Repository<ClinicalForm>,
    private readonly s3_storage: S3Service,
  ) {}

  generateS3Key(patientId: string, uuid: string) {
    return `patients/${patientId}/clinical-forms/${uuid}`;
  }

  getManyByPatientId = async (patientId: string) => {
    return this.clinicalFormRepository
      .createQueryBuilder('clinicalForm')
      .where('clinicalForm.patientId= :patientId', { patientId })
      .orderBy('clinicalForm.updatedAt', 'DESC')
      .getMany();
  };

  getLatestClinicalFormsByPatientId = async (patientId: string) => {
    try {
      const clinical_form = await this.getLatestOneClinicalForm(patientId);
      if (!clinical_form) {
        throw new Error('Clinical form not found');
      }
      return this.getClinicalFormsByPatientAndUUID(
        patientId,
        clinical_form.uuid,
      );
    } catch (error) {
      return {
        error: 'Failed to retrieve clinical forms by patientId and appointmentId',
        message: error.message,
      };
    }
  };

  getClinicalFormsByAppointmentId = async (
    patientId: string,
    appointmentId: string,
    latest: any,
  ) => {
    try {
      if (latest) {
        const clinical_form = await this.getOneClinicalForm(
          patientId,
          appointmentId,
        );
        if (!clinical_form) {
          throw new Error('Clinical form not found');
        }
        return this.getClinicalFormsByPatientAndUUID(
          patientId,
          clinical_form.uuid,
        );
      }
      return this.getManyClinicalForms(patientId, appointmentId);
    } catch (error) {
      return {
        error:
          'Failed to retrieve clinical forms by patientId and appointmentId',
        message: error.message,
      };
    }
  };

  getClinicalFormsByPatientAndUUID = async (patientId: string, uuid: string) => {
    try {
      let key = this.generateS3Key(patientId, uuid);
      return await this.s3_storage.getData(key);
    } catch (error) {
      return {
        error: 'Failed to retrieve clinical forms by patientId and UUID',
        message: error.message,
      };
    }
  };

  postClinicalForm = async (
    xml: string,
    findings: string,
    clinicalForm: CreateClinicalformType,
  ) => {
    try {
      clinicalForm.uuid = clinicalForm.uuid || generateUuidV4();

      const clinicalFormObj = this.createClinicalForm(clinicalForm);
      this.clinicalFormRepository.save(clinicalFormObj);

      let xmldoc: XmlDocType = this.buildClinicalForm(xml, findings);

      const uploadedObject = await this.uploadClinicalFormToS3(
        clinicalFormObj,
        xmldoc,
      );

      return uploadedObject;
    } catch (error) {
      return {
        error: 'Failed to upload clinical form',
        message: error.message,
      };
    }
  };

  updateClinicalForm = async (
    params: { patientId: string; uuid: string },
    xml: string,
    findings: string,
    clinicalForm: UpdateClinicalformType,
  ) => {
    try {
      await this.updateClinicalFormInDB(params.uuid, clinicalForm);

      let oldClinicalForm = await this.getClinicalFormsByPatientAndUUID(
        params.patientId,
        params.uuid,
      );

      let updatedClinicalForm = { ...oldClinicalForm, ...clinicalForm };

      let xmldoc: XmlDocType = this.buildClinicalForm(xml, findings);

      const uploadedObject = await this.uploadClinicalFormToS3(
        updatedClinicalForm,
        xmldoc,
      );

      return uploadedObject;
    } catch (error) {
      return {
        error: 'Failed to update clinical form',
        message: error.message,
      };
    }
  };

  // Helper functions

  private buildClinicalForm(xml: string, findings: string): XmlDocType {
    let bodyXml: string = this.buildXmlTemplate(xml);
    let bodyFindings: string = this.buildFindings(findings);

    return this.resolveDocuments(bodyXml, bodyFindings);
  }

  private resolveDocuments(xml: string, findings: string): XmlDocType {
    xml = FormBuilder.minifyXml(xml);
    findings = FormBuilder.minifyXml(findings);

    return {
      xml,
      findings,
    };
  }

  private buildXmlTemplate(xml) {
    let bodyXml: any = wrapArray(xml);
    return FormBuilder.buildXmlTemplateFromArray(bodyXml);
  }

  private buildFindings(findings) {
    let bodyFindings: any = wrapArray(findings);
    return FormBuilder.buildFindingsFromArray(bodyFindings);
  }

  private createClinicalForm(clinicalForm: CreateClinicalformType) {
    return this.clinicalFormRepository.create({
      ...clinicalForm,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  private updateClinicalFormInDB(
    uuid: string,
    clinicalForm: UpdateClinicalformType,
  ) {
    return this.clinicalFormRepository.update(
      { uuid },
      { ...clinicalForm, updatedAt: new Date() },
    );
  }

  private async uploadClinicalFormToS3(form: ClinicalForm, xmldoc: XmlDocType) {
    const key = this.generateS3Key(form.patientId, form.uuid);
    const objToUpload = { ...form, ...xmldoc };
    const body = JSON.stringify(objToUpload);

    await this.s3_storage.uploadObject(key, body);

    return objToUpload;
  }

  private getLatestOneClinicalForm(patientId) {
    return this.clinicalFormRepository
      .createQueryBuilder('clinicalForm')
      .where('clinicalForm.patientId= :patientId', { patientId })
      .orderBy('clinicalForm.updatedAt', 'DESC')
      .getOne();
  }

  private getManyClinicalForms(patientId, appointmentId) {
    return this.clinicalFormRepository
      .createQueryBuilder('clinicalForm')
      .where(
        'clinicalForm.patientId = :patientId AND clinicalForm.appointmentId = :appointmentId',
        {
          patientId,
          appointmentId,
        },
      )
      .orderBy('clinicalForm.updatedAt', 'DESC')
      .getMany();
  }

  private getOneClinicalForm(patientId, appointmentId) {
    return this.clinicalFormRepository
      .createQueryBuilder('clinicalForm')
      .where(
        'clinicalForm.patientId = :patientId AND clinicalForm.appointmentId = :appointmentId',
        {
          patientId,
          appointmentId,
        },
      )
      .orderBy('clinicalForm.updatedAt', 'DESC')
      .getOne();
  }
}
