import {
  Controller,
  Get,
  Body,
  Param,
  UseGuards,
  ParseUUIDPipe,
  Query,
  Post,
  ValidationPipe,
  UsePipes,
  Put,
} from '@nestjs/common';
import { ApiOperation, ApiParam } from '@nestjs/swagger';
import { PatientsService } from './patients.service';
import { ClinicalFormsService } from './clinical-forms.service';
import { AuthGuard } from '../auth/auth.guard';
import { CreateClinicalFormDto, UpdateClinicalFormDto } from './dto';
import { EntriesService } from '../entries/entries.service';
import { EntriesDto } from '../entries/entries.dto';
import { ChangesService } from '../entries/changes.service';
import { ImportedEntriesDto } from '../entries/imported_entries.dto';
import { ImportedEntriesService } from '../entries/imported_entries.service'

@UseGuards(AuthGuard)
@Controller('patients')
export class PatientsController {
  constructor(
    private readonly patientsService: PatientsService,
    private readonly clinicalFormsService: ClinicalFormsService,
    private readonly entriesService: EntriesService,
    private readonly changesService: ChangesService,
    private readonly importedEntriesService: ImportedEntriesService
  ) {}

  @ApiOperation({ summary: 'get patient by uuid' })
  @Get(':uuid')
  async getPatientByUUID(@Param('uuid', new ParseUUIDPipe()) uuid: string) {
    return await this.patientsService.getPatientByUUID(uuid);
  }

  @Get(':patientId/encounter-notes')
  @ApiOperation({ summary: "get encounter-notes by patient's id" })
  @ApiParam({ name: 'patientId', description: "patient's id" })
  async getPatientEncounterNotes(@Param('patientId') patientId: any) {
    return await this.patientsService.getPatientEncounterNotes(patientId);
  }

  /* CLINICAL-FORMS HANDLER */

  @Get(':patientId/clinical-forms')
  @ApiParam({ name: 'patientId', description: "patient's id" })
  @ApiOperation({ summary: "get clinical-forms by patient's id" })
  async getClinicalForms(@Param('patientId') patientId: any) {
    return await this.clinicalFormsService.getManyByPatientId(patientId);
  }

  @Get(':patientId/clinical-forms/get-latest')
  @ApiParam({ name: 'patientId', description: "patient's id" })
  @ApiOperation({ summary: "get latests clinical-forms by patient's id" })
  async getLatestClinicalFormsByPatientId(@Param('patientId') patientId: any) {
    return await this.clinicalFormsService.getLatestClinicalFormsByPatientId(
      patientId,
    );
  }

  @Get(':patientId/appointments/:appointmentId/clinical-forms')
  @ApiParam({ name: 'patientId', description: "patient's id" })
  @ApiParam({ name: 'appointmentId', description: "appointment's id" })
  @ApiOperation({ summary: "get latests clinical-forms by patient's id" })
  async getClinicalFormsByAppointmentId(
    @Param('patientId', new ParseUUIDPipe()) patientId: string,
    @Param('appointmentId', new ParseUUIDPipe()) appointmentId: string,
    @Query('latest') latest: string,
  ) {
    return await this.clinicalFormsService.getClinicalFormsByAppointmentId(
      patientId,
      appointmentId,
      latest,
    );
  }

  @Get(':patientId/clinical-forms/:uuid')
  @ApiParam({ name: 'patientId', description: "patient's id" })
  @ApiOperation({ summary: "get one clinical-form by patient's id and uuid" })
  async getClinicalFormsByPatientAndUUID(@Param() params: any) {
    const patientId = params.patientId;
    const uuid = params.uuid;
    return await this.clinicalFormsService.getClinicalFormsByPatientAndUUID(
      patientId,
      uuid,
    );
  }

  @ApiOperation({ summary: 'create clinical form' })
  @Post(':patientId/clinical-forms')
  @UsePipes(new ValidationPipe())
  async postClinicalForm(@Body() dto: CreateClinicalFormDto) {
    const { xml, findings, ...clinicalForm } = dto;

    return await this.clinicalFormsService.postClinicalForm(
      xml,
      findings,
      clinicalForm,
    );
  }

  @ApiOperation({ summary: 'create clinical form' })
  @Put(':patientId/clinical-forms/:uuid')
  @UsePipes(new ValidationPipe())
  async updateClinicalForm(
    @Body() dto: UpdateClinicalFormDto,
    @Param() params: { patientId: string; uuid: string },
  ) {
    const { xml, findings, ...clinicalForm } = dto;

    return await this.clinicalFormsService.updateClinicalForm(
      params,
      xml,
      findings,
      clinicalForm,
    );
  }

  /* ENTRIES HANDLER */

  @UseGuards(AuthGuard)
  @Get(':patientId/entries')
  @ApiOperation({ summary: "get entries by patient's id" })
  async getEntriesByPatientId(@Param('patientId') patientId: any) {
    return await this.entriesService.getEntriesByPatientId(patientId);
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Create entries for a patient using patient id' })
  @Post(':patientId/entries')
  @UsePipes(new ValidationPipe())
  async postEntries(
    @Param('patientId') patientId: string,
    @Body() dto: { patientId: string, entries: EntriesDto[] }
    ): Promise<any> { 
      const { entries } = dto 
      return this.entriesService.postEntries(patientId, entries);
    }

  @UseGuards(AuthGuard)
  @Get('/:patientId/changes')
  @ApiOperation({ summary: "get changes by patient's id" })
  async getChangesByPatientId(@Param('patientId') patientId:any) {
      return await this.changesService.getChangesByPatientId(patientId);
  }
  
  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Create imported entries for a patient using patient id' })
  @Post(':patientId/imported-entries')
  @UsePipes(new ValidationPipe())
  async postImportedEntries(
    @Param('patientId') patientId: string,
    @Body() dto: ImportedEntriesDto,
  ): Promise<any> {
    let importedEntries: ImportedEntriesDto[];
    importedEntries = [dto]
    return this.importedEntriesService.postImportedEntries(patientId, importedEntries);
  } 
}
