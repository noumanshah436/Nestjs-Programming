import {
  Entity,
  PrimaryColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('patients')
export class Patient {
  @PrimaryColumn({ length: 255 })
  id: string;

  @Column({ type: 'varchar', length: 255 })
  lastName: string;

  @Column({ type: 'varchar', length: 255 })
  firstName: string;

  @Column({ type: 'varchar', length: 255 })
  birthDate: string;

  @Column({ type: 'varchar', length: 255 })
  sex: string;

  @Column({ type: 'varchar', length: 255 })
  race: string;

  @Column({ type: 'varchar', length: 255 })
  religion: string;

  @Column({ type: 'varchar', length: 255 })
  ethnicity: string;

  @Column({ type: 'varchar', length: 255 })
  maritalStatus: string;

  @CreateDateColumn({ type: 'datetime' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'datetime' })
  updatedAt: Date;
}
