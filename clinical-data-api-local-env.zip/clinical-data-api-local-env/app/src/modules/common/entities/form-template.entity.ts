
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity("form_template")
export class FormTemplate {
  @PrimaryGeneratedColumn("uuid")
  uuid: string;

  @Column()
  name: string;

  @Column()
  code: string;

  @Column()
  type: string;

  @Column()
  createdAt: Date;

  @Column()
  updatedAt: Date;
}