
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity("clinical_forms")
export class ClinicalForm {
  @PrimaryGeneratedColumn("uuid")
  uuid: string;

  @Column()
  patientId: string;

  @Column()
  formTemplateConfigUuid: string;

  @Column()
  businessEntityId: string;

  @Column()
  type: string;

  @Column()
  createdAt: Date;

  @Column()
  updatedAt: Date;

  @Column()
  appointmentId: string;
}