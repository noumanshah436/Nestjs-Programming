import { Injectable } from '@nestjs/common';
import { InjectS3, S3 } from 'nestjs-s3';
import type { Readable } from 'stream';
@Injectable()
export class S3Service {
  constructor(@InjectS3() private readonly s3: S3) {}
  async getData(key) {
    try {
      const input = {
        Bucket: 'development.quippe-patient-data-provider',
        Key: key,
      };
      const response = await this.s3.getObject(input);
      const stream = response.Body as Readable;

      // convert stream to buffer
      const buffer = await new Promise<Buffer>((resolve, reject) => {
        const chunks: Buffer[] = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.once('end', () => resolve(Buffer.concat(chunks)));
        stream.once('error', (error) =>
          reject(`Error converting stream: ${error}`),
        );
      });

      // convert buffer to object
      return JSON.parse(buffer.toString());

    } catch (error) {
      throw new Error(`S3 data retrieval failed: ${error.message}`);
    }
  }

  async uploadObject(key: string, body: string) {
    return new Promise((resolve, reject) => {
      const params = {
        Bucket: 'development.quippe-patient-data-provider',
        Key: key,
        Body: body,
        ServerSideEncryption: 'AES256',
        ContentType: 'text/plain',
      };

      this.s3.putObject(params, (err, data) => {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  }
}
