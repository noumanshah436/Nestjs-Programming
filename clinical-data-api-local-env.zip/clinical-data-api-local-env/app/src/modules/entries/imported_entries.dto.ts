export class ImportedEntriesDto {
  medcinId: number;
  chartFlag: number;
  rangeNormalHigh: number;
  rangeNormalLow: number;
  rangeScale: number;
  specifier: string;
  text: string;
  timeRecorded: string;
  patientId: string;
  referenceRange: string;
}