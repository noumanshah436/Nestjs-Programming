import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Encounter } from '../common/entities/encounter-notes.entity';
import { S3Service } from '../common/s3.service';
import { EntriesDto } from './entries.dto';

@Injectable()
export class EntriesService {
  constructor(
    @InjectRepository(Encounter) private encounterRepository: Repository<Encounter>,
    private readonly s3_storage: S3Service
  ) {}

  getEntriesByPatientId = async (patientId) => {
    try {
      let key = `patients/${patientId}/entries`;
      return await this.s3_storage.getData(key);
    } catch (error) {
      return {
        error: 'Failed to retrieve entries by patient id',
        message: error.message,
      };
    }
  };

  getPatientEncounterNotes = async (patientId): Promise<any> => {
    return await this.encounterRepository
      .createQueryBuilder('encounters')
      .where('encounters.patientId= :patientId', { patientId })
      .orderBy('encounters.baseDate', 'DESC')
      .getMany();
  };
  
  async postEntries(patientId: string, dtos: EntriesDto[]): Promise<any> {
    try {
      const key = EntriesService.generateS3Key(patientId);
      const objToUpload = { patientId, entries: dtos }; 
      const body = JSON.stringify(objToUpload);
      await this.s3_storage.uploadObject(key, body);
  
      return objToUpload;
    } catch (error) {
      return {
        error: 'Failed to upload entries',
        message: error.message,
      };
    }
    
  }

  static generateS3Key( patientId: string ): string {
    return `patients/${patientId}/entries`;
  }
}
