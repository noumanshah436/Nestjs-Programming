import { Injectable } from '@nestjs/common';
import { S3Service } from '../common/s3.service';
import { ImportedEntriesDto } from './imported_entries.dto';

@Injectable()
export class ImportedEntriesService {
  constructor(
    private readonly s3_storage: S3Service
  ) {}

    async postImportedEntries(patientId: string, dtos: ImportedEntriesDto[]): Promise<any> {
      try {
        const key = ImportedEntriesService.generateS3Key(patientId);
        const objToUpload = { patientId, importedEntries: dtos };
        const body = JSON.stringify(objToUpload);

        await this.s3_storage.uploadObject(key, body);

        return objToUpload;
      } catch (error) {
        return {
          error: 'Failed to upload imported entries',
          message: error.message,
        };
      }
    }


    static generateS3Key(patientId: string): string {
      return `patients/${patientId}/imported-entries`;
    }
  }

