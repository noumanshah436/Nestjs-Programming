import { DOMParser, XMLSerializer } from '@xmldom/xmldom';
const prettyData = require('pretty-data').pd;

export class FormBuilder {
  static get documentXmlString(): string {
    return '<Document></Document>';
  }

  static get findingsXmlString(): string {
    return '<Findings></Findings>';
  }

  static get findingsXmlNode() {
    const findingsDoc = new DOMParser().parseFromString(
      FormBuilder.findingsXmlString,
      'text/xml',
    );
    return findingsDoc.firstChild;
  }

  static get documentXmlNode() {
    const xml = FormBuilder.documentXmlString;
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    return doc.firstChild;
  }

  static minifyXml(xmlString: string): string {
    return prettyData.xmlmin(xmlString, [true]).replace(/\r|\n/g, '');
  }

  static buildFindingsFromArray(findingsArray: string[]): string {
    const newForm = FormBuilder.findingsXmlNode;
    findingsArray.forEach((findingString) => {
      const findingNodes = new DOMParser()
        .parseFromString(findingString, 'text/xml')
        .getElementsByTagName('Finding');
      for (const finding of Array.from(findingNodes)) {
        if (finding.attributes.getNamedItem('Result')) {
          newForm.appendChild(finding.cloneNode(true));
        }
      }
    });
    return new XMLSerializer().serializeToString(newForm);
  }

  static buildXmlTemplateFromArray(xmlTemplates: string[]): string {
    const newTemplate = FormBuilder.documentXmlNode;
    xmlTemplates.forEach((xmlString) => {
      const element = new DOMParser().parseFromString(xmlString, 'text/xml');
      const template = element.getElementsByTagName('Document')[0];
      const childNodes = Array.from(template.childNodes);
      childNodes.forEach((childNode) => {
        newTemplate.appendChild(childNode.cloneNode(true));
      });
    });
    return new XMLSerializer().serializeToString(newTemplate);
  }
}
