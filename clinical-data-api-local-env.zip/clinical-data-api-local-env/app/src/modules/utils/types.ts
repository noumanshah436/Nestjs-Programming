export type CreateEncounterNoteType = {
  id: string;
  patientId: string;
  providerId: string;
  baseDate: string;
  code: string;
  description: string;
  encounterTime: string;
};

export type CreateClinicalformType = {
  uuid?: string;
  patientId: string;
  formTemplateConfigUuid: string;
  businessEntityId: string;
  type: string;
  appointmentId: string;
};

export type UpdateClinicalformType = {
  patientId?: string;
  formTemplateConfigUuid?: string;
  businessEntityId?: string;
  type?: string;
  appointmentId?: string;
};

export type XmlDocType = {
  xml: string;
  findings: string;
};

