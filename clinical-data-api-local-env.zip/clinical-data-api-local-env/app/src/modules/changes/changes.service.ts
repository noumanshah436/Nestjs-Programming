import { Injectable } from '@nestjs/common';

@Injectable()
export class ChangesService {
  constructor() {}

  getChangesByPatientId = async (patientId) => {
    return 'true';
  }
}
