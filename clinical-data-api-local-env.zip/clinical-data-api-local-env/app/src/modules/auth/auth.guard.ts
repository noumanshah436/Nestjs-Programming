import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { AuthService } from './auth.service';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private readonly authService: AuthService,
        private readonly configService: ConfigService,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {

        const config  = this.configService.get('auth');

        if(config.enabled === 'false'){
            return true;
        }

        const request: Request = context.switchToHttp().getRequest();
        const authHeader = request.header('Authorization');
        if (!authHeader) { 
            throw new HttpException('Authorization: token missing', HttpStatus.UNAUTHORIZED);
        }

        const contentType = request.header('Content-Type');
        if (!contentType) {
            throw new HttpException('Authorization: ContentType header missing', HttpStatus.UNAUTHORIZED);
        }

        const parts = authHeader.split(' ');
        if (parts.length !== 2 || parts[0] !== 'Carecloud') {
            throw new HttpException('Authorization: Bearer <token> header invalid', HttpStatus.UNAUTHORIZED);
        }

        const token = parts[1];
        const contentTypeHeader = request.header('Content-Type');
        if (!contentTypeHeader) { 
            throw new HttpException('Authorization: content-type header missing', HttpStatus.UNAUTHORIZED);
        }

        const date = request.header('Date');
        if (!date) { 
            throw new HttpException('Authorization: date missing', HttpStatus.UNAUTHORIZED);
        }

        try {
            return await this.authService.authenticate(context, contentType, token, date);
        } catch (e) {
            throw new HttpException(e.message, HttpStatus.UNAUTHORIZED);
        }
    }
}
