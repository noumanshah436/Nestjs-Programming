import { Injectable, ExecutionContext } from '@nestjs/common';
import { CareCloudInternalAuth } from '@carecloud/cc-auth-node';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AuthService {

    carecloudInternalAuth: any;

    constructor(
        private configService: ConfigService,
    ) {
        this.carecloudInternalAuth = new CareCloudInternalAuth({
            internalApiKey: this.configService.get('auth').apiKey,
            internalSignatureSecret: this.configService.get('auth').secret,
            authServiceUrl: this.configService.get('auth').authServiceUrl
          });
    }

    async authenticate(context: ExecutionContext, contentTypeHeader: string, token: string, date: string) {

        const request: Request = context.switchToHttp().getRequest();    

        const options: any = {
            reqMethod: request.method,
            reqContentType: contentTypeHeader,
            reqPath: request.url,
            timestamp: date,
            Authorization: token,
            reqPayload: request.body
        }

        console.log("Options for auth: ", options);

        return await this.carecloudInternalAuth.byAuthService(options)
            .then((result) => {console.log("Auth result:",result);return true;})
            .catch((err) => {console.log("Auth error:",err);return false;});
    }
}

