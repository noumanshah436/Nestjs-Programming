import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { ConfigModule } from '@nestjs/config';

@Module({
    imports: [
        HttpModule,
        ConfigModule
    ],
    providers: [
        AuthGuard,
        AuthService
    ],
    exports: [
        AuthService,
    ],
})
export class AuthModule {}
