import { IsDateString, IsNotEmpty, IsString } from 'class-validator';

export class CreateEncounterNoteDto {
  @IsString()
  @IsNotEmpty()
  id: string;

  @IsDateString()
  @IsNotEmpty()
  baseDate: string;

  @IsString()
  @IsNotEmpty()
  code: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsDateString()
  @IsNotEmpty()
  encounterTime: string;

  @IsString()
  @IsNotEmpty()
  patientId: string;

  @IsString()
  @IsNotEmpty()
  providerId: string;

  @IsString()
  @IsNotEmpty()
  xml: string;
}
