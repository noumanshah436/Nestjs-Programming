import { Module } from '@nestjs/common';
import { EncounterNotesController } from './encounter_notes.controller';
import { EncounterNotesService } from './encounter_notes.service';
import { AuthModule } from '../auth/auth.module';
import { ConfigModule } from '@nestjs/config';
import { S3Service } from '../common/s3.service';
import { CommonModule } from '../common/common.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Encounter } from '../common/entities/encounter-notes.entity';

@Module({
  imports: [
    ConfigModule, 
    AuthModule,
    CommonModule,
    TypeOrmModule.forFeature([Encounter])
  ],
  controllers: [EncounterNotesController],
  providers: [EncounterNotesService, S3Service],
})
export class EncounterNotesModule {}
