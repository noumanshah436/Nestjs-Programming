import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Post,
  UseGuards,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { ApiOperation, ApiParam } from '@nestjs/swagger';
import { AuthGuard } from '../auth/auth.guard';
import { EncounterNotesService } from './encounter_notes.service';
import { CreateEncounterNoteDto } from './dto';

@Controller('encounter-notes')
export class EncounterNotesController {
  constructor(private readonly encounterNotesService: EncounterNotesService) {}

  @UseGuards(AuthGuard)
  @ApiParam({ name: 'uuid', description: 'uuid' })
  @ApiOperation({ summary: 'get encounter notes by uuid' })
  @Get(':uuid')
  async getEncounterNotesByUUID(@Param('uuid', ParseIntPipe) uuid: number) {
    return await this.encounterNotesService.getEncounterNotesByUUID(uuid);
  }

  @UseGuards(AuthGuard)
  @ApiParam({ name: 'uuid', description: 'uuid' })
  @ApiOperation({ summary: 'get encounter notes content type' })
  @Get(':uuid/content-type')
  getEncounterNotesContentType(@Param('uuid', ParseIntPipe) uuid: number) {
    return this.encounterNotesService.getEncounterNotesContentType();
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'get encounter notes content type' })
  @Post()
  @UsePipes(new ValidationPipe())
  async postEncounterNotes(
    @Body() dto: CreateEncounterNoteDto,
  ) {
    const { xml, ...encounterNote } = dto
    let result = await this.encounterNotesService.postEncounterNotes(encounterNote, xml);
    return result;
  }
}
