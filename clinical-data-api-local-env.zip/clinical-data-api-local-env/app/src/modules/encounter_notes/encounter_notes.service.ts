import { Injectable } from '@nestjs/common';
import { S3Service } from '../common/s3.service';
import { InjectRepository } from '@nestjs/typeorm';
import { Encounter } from '../common/entities/encounter-notes.entity';
import { Repository } from 'typeorm';
import { CreateEncounterNoteType } from '../utils/types';

@Injectable()
export class EncounterNotesService {
  constructor(
    private readonly s3_storage: S3Service,
    @InjectRepository(Encounter)
    private encounterRepository: Repository<Encounter>,
  ) {}

  s3Prefix() {
    return 'encounter-notes';
  }

  generateS3Key(uuid) {
    return `${this.s3Prefix()}/${uuid}`;
  }

  async getEncounterNotesByUUID(uuid: number) {
    try {
      return await this.s3_storage.getData(this.generateS3Key(uuid));
    } catch (error) {
      return {
        error: 'Failed to retrieve encounter notes',
        message: error.message,
      };
    }
  }

  getEncounterNotesContentType() {
    return 'application/vnd.medicomp.quippe.note+xml';
  }

  async postEncounterNotes(dto: CreateEncounterNoteType, xml: string) {
    try {
      const encounter_note = this.createEncounterNote(dto);
      await this.encounterRepository.save(encounter_note);

      const uploadedObject = await this.uploadEncounterNoteToS3(dto.id, dto, xml);

      return uploadedObject;
    } catch (error) {
      return {
        error: 'Failed to upload encounter notes',
        message: error.message,
      };
    }
  }

  private createEncounterNote(dto: CreateEncounterNoteType) {
    return this.encounterRepository.create({
      ...dto,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  private async uploadEncounterNoteToS3(
    id: string,
    dto: CreateEncounterNoteType,
    xml: string,
  ) {
    const key = this.generateS3Key(id);
    const objToUpload = { ...dto, xml };
    const body = JSON.stringify(objToUpload);

    await this.s3_storage.uploadObject(key, body);

    return objToUpload;
  }
}
