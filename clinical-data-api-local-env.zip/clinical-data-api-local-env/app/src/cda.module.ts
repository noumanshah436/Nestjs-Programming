import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { S3Module } from 'nestjs-s3';

import { CdaController } from './cda.controller';
import { CdaService } from './cda.service';

import { CommonModule } from './modules/common/common.module';
import { PatientsModule } from './modules/patients/patients.module';
import { FormTemplatesModule } from './modules/form-templates/form-templates.module';
import { EncounterNotesModule } from './modules/encounter_notes/encounter_notes.module';


// Typeorm entities
import { Patient } from './modules/common/entities/patient.entity';
import { Encounter } from './modules/common/entities/encounter-notes.entity';
import { ClinicalForm } from './modules/common/entities/clinical-form.entity';
import { FormTemplate } from './modules/common/entities/form-template.entity';

import configuration from './config';

@Module({
  imports: [
    ConfigModule.forRoot({load: [configuration]}),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => {
        const dbConfig = config.get('database');
        //console.log("INIT DB CONFIG", dbConfig);
        return {
          type: dbConfig.type,
          host: dbConfig.host,
          port: dbConfig.port,
          database: dbConfig.database,
          username: dbConfig.username,
          password: dbConfig.password,
          entities: [ClinicalForm, Patient, Encounter, FormTemplate],
          synchronize: false
        }
      },
      inject: [ConfigService],
    }),
    S3Module.forRoot(
      {config: {
        credentials: {
          accessKeyId: process.env.AWS_ACCESS_KEY_ID,
          secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
          sessionToken: process.env.AWS_SESSION_TOKEN,
        },
        region: process.env.AWS_S3_REGION,
      },
    }),
    CommonModule,
    PatientsModule,
    EncounterNotesModule,
    FormTemplatesModule,
    CommonModule
  ],
  controllers: [CdaController],
  providers: [CdaService],
})
export class CdaModule {}
