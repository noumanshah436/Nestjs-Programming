export default () => ({
    environment: process.env.NODE_ENV,
    auth: {
      enabled: process.env.ENABLE_AUTHORIZATION,
      apiKey: process.env.INTERNAL_API_KEY,
      secret: process.env.TOKEN_SIGNATURE_SECRET,
      authServiceUrl: process.env.AUTH_SERVICE_URL
    },
    database: {
      type: process.env.DB_DIALECT,
      host: process.env.DB_HOST,
      port: process.env.DB_PORT,
      database: process.env.DB_NAME,
      username: process.env.DB_USER,
      password: process.env.DB_PASS,
    },
    aws: {
      //project: process.env.SERVERLESS_PROJECT,
      //stage: process.env.SERVERLESS_STAGE,
      region: process.env.AWS_S3_REGION,
      bucket: process.env.AWS_S3_BUCKET,
      accessKey: process.env.AWS_ACCESS_KEY_ID,
      secretKey: process.env.AWS_SECRET_ACCESS_KEY,
      token: process.env.AWS_SESSION_TOKEN,
    },
    s3: {
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
      region: 'us-east-1',
      forcePathStyle: true,
      signatureVersion: 'v4',
    }

  });
    