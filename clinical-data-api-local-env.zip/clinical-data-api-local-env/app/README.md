# Clinical Data API

TODO: Update this file with project description and instructions on running local environment